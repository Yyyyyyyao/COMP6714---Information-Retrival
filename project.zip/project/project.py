def encode(posting_list):
    pass


def decode(posting_list_encode):
    pass


def evaluation(rel_list, total_rel_doc):
    pass